# CarDekho-SQL-Queries
SQL project using the CarDekho database to answer key automotive questions. Focuses on writing and optimizing basic SQL queries to extract insights on car fuel type and trends. A practical exercise in querying and data retrieval for beginners.
